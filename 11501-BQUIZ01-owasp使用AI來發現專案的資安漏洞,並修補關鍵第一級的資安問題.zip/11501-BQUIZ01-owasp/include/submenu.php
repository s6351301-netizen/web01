<?php
/**
 * 於 2026-08-14 的安全修復中加上守門。
 *
 * 本檔是由後台以 AJAX 載入的表單片段，但它同時也是一個可以被直接
 * 開啟的 URL（例如 http://站台/include/xxx.php）。舊版完全沒有驗證，
 * 未登入者即可取得後台表單結構（對應 A01-3）。
 */
require_once __DIR__ . '/../api/auth.php';
require_once __DIR__ . '/../api/csrf.php';
require_login();
?>
<h3 class="cent">編輯次選單</h3>
<hr>
<form action="api/submenu.php?table=menu" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <table class="all" style="width:70%; margin:auto;" id="subMenu">
        <tr>
            <td class="tt">次選單名稱</td>
            <td class="tt">次選單連結網址</td>
            <td class="tt">刪除</td>
        </tr>
        <?php
        $mainId = (int)($_GET['id'] ?? 0);
        if($mainId > 0 && $Menu->count(['main_id'=>$mainId])>0):
            $rows=$Menu->all(['main_id'=>$mainId]);
            foreach($rows as $row):
        ?>
        <tr>
            <td><input type="text" name="text[]" value="<?= $row['text']; ?>"></td>
            <td><input type="text" name="href[]" value="<?= $row['href']; ?>"></td>
            <td><input type="checkbox" name="del[]" value="<?= $row['id']; ?>"></td>
            <input type="hidden" name="id[]" value="<?= $row['id']; ?>">
        </tr>
        <?php
            endforeach;
            endif;
        ?>
    </table>
    <div class="cent">
        <input type="hidden" name="main_id" value="<?= $mainId ?>">
        <input type="submit" value="修改確定">
        <input type="reset" value="重置">
        <input type="button" value="更多次選單" onclick="more()">
    </div>
    </form>
<script>
    
function more(){
    let row=`<tr>
                <td><input type="text" name="text2[]"></td>
                <td><input type="text" name="href2[]"></td>
                <td></td>
            </tr>`
     $('#subMenu').append(row)


}
</script>